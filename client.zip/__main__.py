#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys

import client.client_json

##########################################
### Main ###
if __name__ == '__main__':
    if len(sys.argv) <= 2:
        print("Ce client prend l'adresse IP et le numéro du port en paramètre.")
        sys.exit(1)

    # Récupérer l'adresse IP en paramètre du serveur.
    host = sys.argv[1]

    # Récurérer le numéro du port en paramètre du serveur.
    port = int(sys.argv[2])

    # racine = './'
    racine = '/root/dropbox/'

    conn_client = client.client_json.Client(host, port)

    print("Synchronisation de l'arborescence pour le dossier '" + racine + "'...")
    conn_client.miseAjour(racine)
    print("Synchronisation terminée.")
