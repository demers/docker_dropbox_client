#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys
import socket

import client.client_json

MAX_RECV = 1024 * 1024 * 512

##########################################
### Main ###
if __name__ == '__main__':

    if len(sys.argv) <= 2:
        print("Ce client prend l'adresse IP et le numéro du port en paramètre.")
        print("Si le troisième paramètre est \"--archive\", le client demande")
        print("une archive ZIP de l'arborescence (fichier archive.zip)")
        sys.exit(1)

    # Récupérer l'adresse IP en paramètre du serveur.
    host = sys.argv[1]

    # Récurérer le numéro du port en paramètre du serveur.
    port = int(sys.argv[2])

    archivage = False
    if len(sys.argv) <= 3:
        if sys.argv[3] == '--archive':
            archivage = True

    racine = './'

    conn_client = client.client_json.Client(host, port)

    if not archivage:

        print("Synchronisation de l'arborescence pour le dossier '" + racine + "'...")
        conn_client.miseAjour(racine)
        print("Synchronisation terminée.")
        sys.exit(0)
    else:
        print("Demande d'archive ZIP de l'arborescence...")
        s = socket.socket()
        s.connect((host, port))
        json_archivage = {"archive": ""}
        texte_archivage = json.dumps(json_archivage) + "\r\n"
        s.send(texte_archivage.encode(encoding='UTF-8'))
        s.close()

