#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys
import socket

import client.client_json

MAX_RECV = 1024 * 1024 * 512

HOST = ''

def verifie_syntaxe(msgApp):
    "Analyse la syntaxe JSON du message du serveur"
    try:
        json.loads(msgApp)
        reponse = True
    except:
        reponse = False

    return reponse

##########################################
### Main ###
if __name__ == '__main__':

    if len(sys.argv) <= 2:
        print("Ce client prend l'adresse IP et le numéro du port en paramètre.")
        print("Si le troisième paramètre est \"--archive\", le client demande")
        print("une archive ZIP de l'arborescence (fichier archive.zip)")
        sys.exit(1)

    # Récupérer l'adresse IP en paramètre du serveur.
    host = sys.argv[1]

    # Récurérer le numéro du port en paramètre du serveur.
    port = int(sys.argv[2])

    archivage = False
    if len(sys.argv) <= 3:
        if sys.argv[3] == '--archive':
            archivage = True

    racine = './'

    conn_client = client.client_json.Client(host, port)

    if not archivage:

        print("Synchronisation de l'arborescence pour le dossier '" + racine + "'...")
        conn_client.miseAjour(racine)
        print("Synchronisation terminée.")
        sys.exit(0)
    else:
        print("Demande d'archive ZIP de l'arborescence...")
        client = socket.socket()
        client.connect((host, port))
        json_archivage = {"archive": ""}
        texte_archivage = json.dumps(json_archivage) + "\r\n"
        client.send(texte_archivage.encode(encoding='UTF-8'))
        client.close()

        print("Attente de réception de l'archive...")
        serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        serveur.bind((self.HOST, self.PORT))
        serveur.listen(5)
        connexion, adresse = serveur.accept()

        compteur = 1
        texte_recu_total = ''
        MAX_NOMBRE_RECV = 100
        while compteur < MAX_NOMBRE_RECV:
            texte_recu = connexion.recv(MAX_RECV).decode(encoding='UTF-8')
            if compteur > 1:
                print('Attente du contenu... (' + str(compteur) + '/' + str(MAX_NOMBRE_RECV) + ')')
            compteur += 1
            texte_recu_total += texte_recu
            if verifie_syntaxe(texte_recu_total):
                break
            else:
                print("Attention, le texte reçu jusqu'à maintenant n'est pas syntaxiquement correct.")
                print("Attente de la suite...")
                print("(Faire CTRL-C s'il y a erreur)")
        if compteur >= MAX_NOMBRE_RECV:
            print("Réponse définitive: le texte du serveur reçu n'est pas syntaxiquement correct.")
            serveur.close()
            sys.exit(1)

        print("Réception terminée. Enregistrement de l'archive...")
        serveur.close()

        signature = ''
        contenu = ''
        date = ''
        dom = json.loads(texte_recu_total)
        for node in self.dom:
            if node == 'fichier':
                node_interne = dom[node]
                for node2 in node_interne:
                    if node2 == 'signature':
                        signature = node_interne[node2]
                    if node2 == 'contenu':
                        contenu = node_interne[node2]
                    if node2 == 'date':
                        date = node_interne[node2]

        # à compléter...




